class SiteHeader extends HTMLElement {
    connectedCallback() {

        const depth = window.location.pathname.split('/').length-2
        const raiz = '../'.repeat(depth)

        this.innerHTML =`
            <header class="cabecalho">
                <a href="${raiz}pages/inicio.html" class="logo">Tech Aula</a>

                <nav class="navegacao">
                    <a href="${raiz}pages/inicio.html">Início</a>
                    
                    <div class="dropdown">
                        <a href="#">Serviços <span class="seta">▾</span></a>
                        <div class="submenu">
                            <a href="${raiz}pages/servicos/instalacao.html">Instalação e configuração</a>
                            <a href="${raiz}pages/servicos/montagem.html">Montagem e manutenção</a>
                            <a href="${raiz}pages/servicos/formatacao.html">Formatação e instalação</a>
                        </div>
                    </div>

                    <div class="dropdown">
                        <a href="#">Cursos <span class="seta">▾</span></a>
                        <div class="submenu">
                            <a href="${raiz}pages/cursos/html.html">HTML</a>
                            <a href="${raiz}pages/cursos/css.html">CSS</a>
                            <a href="${raiz}pages/cursos/frontend.html">FRONT-END</a>
                            <a href="${raiz}pages/cursos/javascript.html">JAVA SCRIPT</a>
                        </div>
                    </div>
                    <a href="${raiz}pages/produtos.html">Produtos</a>
                    <a href="${raiz}pages/avaliacoes.html">Avaliações</a>
                    <a href="${raiz}pages/horario.html">Horário de atendimento</a>
                </nav>
        </header>`
    }
}
customElements.define('site-header', SiteHeader);