class SiteFooter extends HTMLElement {
    connectedCallback() {
        this.innerHTML =`
        <footer class="rodape">
            <p>&copy; 2026 3º ADS - Desenvolvido por ciclano e fulano</p>
        </footer>`
    }
}

customElements.define('site-footer', SiteFooter);